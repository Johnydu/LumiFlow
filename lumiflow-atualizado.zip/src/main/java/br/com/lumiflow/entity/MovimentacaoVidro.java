package br.com.lumiflow.entity;

import br.com.lumiflow.entity.enums.TipoMovimentacao;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;


import java.time.LocalDateTime;
import java.util.Locale;

@Entity
@Table(name = "movimentacao_vidro")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(of = "id", callSuper = false)
public class MovimentacaoVidro extends Auditoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne( fetch = FetchType.LAZY)
    @JoinColumn(name = "chapa_vidro_id")
    private ChapaVidro chapaVidro;

    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_movimentacao",length = 20,nullable = false)
    private TipoMovimentacao tipoMovimentacao;

    @Column(name = "quantidade",nullable = false)
    private Integer quantidade;

    @Column(name = "observacao",length = 100)
    private String observacao;

    @DateTimeFormat
    @Column(name = "data_hora")
    private LocalDateTime dataHora;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "operador_id", nullable = false)
    @NotNull(message = "O operador responsável é obrigatório")
    private Operador operador; //

    @PrePersist
    @PreUpdate
    private void normalizarTextos() {
        if (observacao != null) observacao = observacao.trim().toUpperCase(Locale.ROOT);
    }
}
